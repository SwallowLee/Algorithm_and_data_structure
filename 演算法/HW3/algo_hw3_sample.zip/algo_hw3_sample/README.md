# Algo Hw3 Example binary input, output

:::warning
- [UPDATE_0418 - Given `output_example.txt` differ from my encoded binary :(.](https://hackmd.io/CwDgpgjAxmCcBGBaeAmMTgQIYsSKKAJolgGYBsAzIefFPJQOyFA=?both#update-0418)
:::

This Directory consists of:
- `input_example.txt`:
  - Binary(encoded) input for example input in HomeworkSpec.

- `output_example.txt`
  - Binary(encoded) output for example output in HomeworkSpec.
  - **This binary is encoded using msgpack-python's packb() method.**

- `output_example.txt.cpp`
  - Binary(encoded) output for example output in HomeworkSpec too.
  - **This binary is encoded using msgpack-cpp's msgpack::pack() method.**
